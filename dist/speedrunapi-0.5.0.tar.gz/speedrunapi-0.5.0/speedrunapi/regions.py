from speedrunapi import Misc_Requests

class Regions:
    def __init__(self):
        pass
'''
region_games = loads(urlopen(url).read().decode('utf-8'))['data']['links'][0]['uri']
region_runs = loads(urlopen(url).read().decode('utf-8'))['data']['links'][1]['uri']
'''
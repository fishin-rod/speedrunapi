SpeedrunAPI
===
A library for working with speedrun.coms API

Docs: 'https://speedrunapi.readthedocs.io'
The docs should contain all the nessiasary info on how to use the library, The docs should go into depth about most of the functions of the library, but some of the descriptions in the docs may lack good examples.

Version: 0.4.4
```python
pip install speedrunapi
```

## If you have any questions or suggestions please feel free to contact me about them, for issues please report them on the project repository
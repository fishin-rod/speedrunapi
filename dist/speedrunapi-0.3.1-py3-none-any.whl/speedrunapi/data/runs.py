
class User_Runs:
    def __init__(self):
        self.name = ""

class Game_runs:
    def __init__(self):
        self.name = ""